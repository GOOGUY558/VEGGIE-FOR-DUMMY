//import javax.swing.JOptionPane;
public class Vegetabletest  {

    public static void main(String[] args) {
        BinarySearchTree BinaryTree = new BinarySearchTree();


        new StartFrame();
    }

}